from database import SessionLocal
from models.project_db import ProjectDB


projects = [
    {
        "project_id": 1427,
        "project_name": "National Highway Project",
        "state": "Uttar Pradesh",
        "sector": "Transport",
        "original_cost": 500,
        "current_cost": 560,
        "physical_progress": 52,
        "financial_progress": 48
    },
    {
        "project_id": 1098,
        "project_name": "Urban Infrastructure Project",
        "state": "Maharashtra",
        "sector": "Urban Development",
        "original_cost": 300,
        "current_cost": 315,
        "physical_progress": 72,
        "financial_progress": 70
    },
    {
        "project_id": 1842,
        "project_name": "Irrigation Development Project",
        "state": "Rajasthan",
        "sector": "Water Resources",
        "original_cost": 400,
        "current_cost": 470,
        "physical_progress": 35,
        "financial_progress": 30
    }
]


db = SessionLocal()

try:
    for project in projects:
        new_project = ProjectDB(**project)
        db.add(new_project)

    db.commit()

    print("Projects inserted successfully!")

except Exception as e:
    db.rollback()
    print("Error:", e)

finally:
    db.close()